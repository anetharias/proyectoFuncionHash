const axios = require('axios');
const crypto = require('crypto');

const instance = axios.create({
    baseURL: 'https://candidates.mifiel.com/api/v1',
    timeout: 1000,
    headers: {'Content-Type': 'application/json'}
  });

function generateHash(challenge) {
  const hash = crypto.createHash('sha256').update(challenge).digest('hex');
  return hash;
}

async function saveUser(user) {
    const response = await instance.post('/users', user);
    const { data } = response;
    return data;
}

async function updateChallenge(id, challenge) {
    try{
        const response = await instance.put(`/users/${id}/challenge/digest`, challenge);
        const { data } = response;
        return data;
    }catch(error) {
        if (error.isAxiosError) {
            const { data } = error.response;
            return data;
        }
        throw Error(`Error in put request: ${error.message}`)
    }
}

async function updatePOW(id, pow) {
    const response = await instance.put(`/users/${id}/challenge/pow`, pow);
    const { data } = response;
    return data;
}

function generarHashcash(challenge, difficulty) {
  let nonce = 0;
  let hash;
  const startTime = Date.now();

  while (true) {
    const data = challenge + nonce;
    hash = generateHash(data);

    if (hash.startsWith('0'.repeat(difficulty))) {
      const endTime = Date.now();
      const timeElapsed = (endTime - startTime) / 1000;
      return { hash, nonce, timeElapsed };
    }
    nonce++;
  }
}

(async () => {
  try {
    const savedUserResponse = await saveUser({
        name: "Aneth Arias",
        email: "anethzng@gmail.com"
    });
    const { next_challenge } = savedUserResponse;
    const hash = generateHash(next_challenge.challenge);
    const updatedChallengeResponse = await updateChallenge(savedUserResponse.id, {
        result: hash
    });
    const { next_challenge: { challenge, difficulty } } = updatedChallengeResponse;
    const hashCashResult = generarHashcash(challenge, difficulty);
    await updatePOW(savedUserResponse.id, { result: hashCashResult.nonce });
    console.info('Proccess ended');
  } catch (error) {
    console.error('Error:', error);
  }
})();
